require('dotenv').config();
export default   {
    apiServer: process.env.API_SERVER_URL,
    token: process.env.TOKEN
}