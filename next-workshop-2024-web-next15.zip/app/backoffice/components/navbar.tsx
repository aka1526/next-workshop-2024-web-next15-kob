export default function Navbar() {
    return (
        <>
            <nav className="main-header navbar navbar-expand navbar-white navbar-light">
                <ul className="navbar-nav"></ul>
            </nav>
        </>
    )
}
